This folder contains a minimal implementation of **The Third Ear Mediation App** with a
"Clear My Head" feature. To deploy it on Vercel:

1. Zip the contents of this `third_ear_app` folder and upload it to a new Vercel project.
2. No external API keys are required; the reflection logic runs entirely on
   the client and simple serverless function.
3. Once deployed, navigate to `/clear-my-head` to access the new feature.
4. If you wish to integrate an LLM service, you can modify
   `api/mediate.js` to call your provider and return a structured response.