// API route for the Third Ear "Clear My Head" feature.
// This handler accepts POST requests containing either a freeTalk string
// or structured fields (facts, story, emotions, desired) and returns
// a structured reflection response. If the body is missing or invalid,
// an error is returned.

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    res.status(405).json({ error: 'Method not allowed' });
    return;
  }

  let body = req.body;
  // In Vercel functions, body may be a string if not parsed. Try JSON.parse.
  if (typeof body === 'string') {
    try {
      body = JSON.parse(body);
    } catch (err) {
      // If parsing fails, return error
      res.status(400).json({ error: 'Invalid JSON payload' });
      return;
    }
  }

  // Determine mode: if freeTalk is provided, treat it as free text
  const {
    facts = '',
    story = '',
    emotions = '',
    desired = '',
    freeTalk = ''
  } = body || {};

  // Summarization helpers (replicate client heuristics)
  function parseEmotions(text) {
    const entries = [];
    const parts = String(text).split(/,|;|\n/).map(s => s.trim()).filter(Boolean);
    parts.forEach(part => {
      const match = part.match(/([a-zA-Z\s]+)(\d+)/);
      if (match) {
        entries.push({ emotion: match[1].trim(), intensity: match[2] });
      } else if (part) {
        entries.push({ emotion: part, intensity: '-' });
      }
    });
    return entries;
  }

  function identifyRoot(text1, text2) {
    const lower = String(text2 || text1).toLowerCase();
    if (lower.includes('not listened') || lower.includes('ignored')) {
      return 'Feeling unheard or dismissed. You value being acknowledged.';
    }
    if (lower.includes('unfair') || lower.includes('taken advantage')) {
      return 'A sense of injustice. You value fairness and respect.';
    }
    return 'Reflect on what core need or fear is most threatened here.';
  }

  function identifyControl() {
    return 'You can control how you communicate and set boundaries. You cannot control how others feel or react.';
  }

  function suggestOptions() {
    return [
      'Take a few deep breaths and ground yourself.',
      'Consider sharing your feelings calmly with the other person.',
      'Write down what you can do differently next time.',
      'Reach out to a trusted friend or professional if needed.'
    ];
  }

  if (freeTalk && freeTalk.trim()) {
    // Free talk processing
    const text = String(freeTalk).trim();
    const sentences = text.split(/\.\s*/);
    const summary = sentences.slice(0, 2).join('. ') + (text.endsWith('.') ? '' : '.');
    const root = identifyRoot(text, '');
    const control = identifyControl();
    const options = suggestOptions();
    res.status(200).json({
      mode: 'free',
      summary,
      root,
      control,
      options
    });
    return;
  }

  // Guided mode processing: require all fields
  if (!facts || !story || !emotions || !desired) {
    res.status(400).json({ error: 'Incomplete data. Provide facts, story, emotions, and desired.' });
    return;
  }

  const summaryParts = [];
  if (facts) summaryParts.push(String(facts).trim());
  if (story) summaryParts.push(String(story).trim());
  if (emotions) summaryParts.push('You felt ' + String(emotions).trim() + '.');
  if (desired) summaryParts.push('You would like ' + String(desired).trim() + '.');
  const summary = summaryParts.slice(0, 3).join(' ');
  const feelings = parseEmotions(emotions);
  const root = identifyRoot(facts, story);
  const control = identifyControl();
  const options = suggestOptions();
  res.status(200).json({
    mode: 'guided',
    summary,
    facts: String(facts).trim(),
    story: String(story).trim(),
    feelings,
    root,
    control,
    options
  });
}